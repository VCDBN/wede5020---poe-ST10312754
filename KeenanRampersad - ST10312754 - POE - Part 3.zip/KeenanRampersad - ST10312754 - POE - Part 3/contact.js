const contactForm = document.getElementById('Email');

contactForm.addEventListener('submit', (event) => {
  event.preventDefault();

  // Your form validation logic here

  // If form is valid, submit it
  contactForm.submit();
});